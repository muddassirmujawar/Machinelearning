 # %%
import pandas as pd
df=pd.read_csv("iris_csv.csv")

# %%
df.head()

# %%
# selection of i/p ando/p variables
# x=df[['still_alive','pceffusion','epss','lvdd','wall_motion_score','mult','wall_motion_index','age']]
import numpy as np 
import seaborn as sns 
x=df.iloc[:,:-1]
y=df.iloc[:,-1:]

# %%
# update 
# df ['grnder']=df['gender'].replace('male',1)
from sklearn.model_selection import train_test_split
x_train,x_test,y_train,y_test=train_test_split(x,y,random_state=0,test_size=0.2)

# %%
x_train.head()

# %%
# y=df['alive_at_1']

# %%
y.head()

# %%
# machine learning algorithm 
from sklearn.tree import DecisionTreeClassifier
# create  model and fir it 
model=DecisionTreeClassifier().fit(x_train,y_train)

# %%
# prediction 
# model.predict([[0,	0,	6.000,	4.100,	14.0,	0.588,	1.70,	72.0]])
from sklearn.tree import plot_tree
plot_tree(model,filled=True)
import matplotlib.pyplot as plt
plt.title('Decision tree model od iris dataset')
# plt.savefig("tiff_compressed.tiff",dpi=600,format="tiff",facecolor="white",edgecolor="none",pil_kwargs={"compression":"tiff_lzw"})
plt.show()


# %%
y_pred=model.predict(x_test)
print(y_pred)

# %%
from sklearn.metrics import accuracy_score
print(accuracy_score(y_pred,y_test))

# %%
x_train,x_test,y_train,y_test=train_test_split(x,y,random_state=0,test_size=0.3)

# %%
model=DecisionTreeClassifier().fit(x_train,y_train)

# %%
y_pred=model.predict(x_test)
print(y_pred)

# %%
print(accuracy_score(y_pred,y_test))

# %%


# %%
x_train,x_test,y_train,y_test=train_test_split(x,y,random_state=0,test_size=0.1)

# %%
model=DecisionTreeClassifier().fit(x_train,y_train)

# %%
y_pred=model.predict(x_test)
print(y_pred)

# %%
print(accuracy_score(y_pred,y_test))

# %%
x_train.head()

# %%
y_pred=[[48,3.2,1.5,0.1],[6.1,3.2,4.5,1.2],[1.2,2.3,5.5,2.3],[2.2,2.2,2.2,2.2],[1.3,2.3,5.3,3.3]]

# %%
y_pred=model.predict(x_test)
print(y_pred)

# %%



